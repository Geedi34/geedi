﻿Public Class Form2

    Private Sub ToolStripComboBox1_Click(sender As Object, e As EventArgs)






    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedIndex = 0 Then
            g.Text = 1
            d.Text = 1
            f.Text = Val(g.Text) + Val(d.Text)
        End If

        If ComboBox1.SelectedIndex = 1 Then
            g.Text = 2
            d.Text = 2
            f.Text = Val(g.Text) + Val(d.Text)
        End If

        If ComboBox1.SelectedIndex = 2 Then
            g.Text = 3
            d.Text = 1.5
            f.Text = Val(g.Text) + Val(d.Text)
        End If
        If ComboBox1.SelectedIndex = 3 Then
            g.Text = 4
            d.Text = 1.5
            f.Text = Val(g.Text) + Val(d.Text)


        End If
    End Sub

    Private Sub txtcost_TextChanged(sender As Object, e As EventArgs) Handles g.TextChanged

    End Sub

End Class