﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txttotal = New System.Windows.Forms.TextBox()
        Me.txttax = New System.Windows.Forms.TextBox()
        Me.txtcost = New System.Windows.Forms.TextBox()
        Me.f = New System.Windows.Forms.Label()
        Me.d = New System.Windows.Forms.Label()
        Me.g = New System.Windows.Forms.Label()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripComboBox1 = New System.Windows.Forms.ToolStripLabel()
        Me.ComboBox1 = New System.Windows.Forms.ToolStripComboBox()
        Me.Panel1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txttotal)
        Me.Panel1.Controls.Add(Me.f)
        Me.Panel1.Controls.Add(Me.d)
        Me.Panel1.Controls.Add(Me.txttax)
        Me.Panel1.Controls.Add(Me.g)
        Me.Panel1.Controls.Add(Me.txtcost)
        Me.Panel1.Font = New System.Drawing.Font("Algerian", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(72, 63)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(259, 160)
        Me.Panel1.TabIndex = 0
        '
        'txttotal
        '
        Me.txttotal.Location = New System.Drawing.Point(13, 99)
        Me.txttotal.Name = "txttotal"
        Me.txttotal.Size = New System.Drawing.Size(101, 39)
        Me.txttotal.TabIndex = 5
        Me.txttotal.Text = "Total ="
        '
        'txttax
        '
        Me.txttax.Location = New System.Drawing.Point(13, 57)
        Me.txttax.Name = "txttax"
        Me.txttax.Size = New System.Drawing.Size(101, 39)
        Me.txttax.TabIndex = 4
        Me.txttax.Text = "tax ="
        '
        'txtcost
        '
        Me.txtcost.Location = New System.Drawing.Point(13, 19)
        Me.txtcost.Name = "txtcost"
        Me.txtcost.Size = New System.Drawing.Size(101, 39)
        Me.txtcost.TabIndex = 3
        Me.txtcost.Text = "Cost ="
        '
        'f
        '
        Me.f.BackColor = System.Drawing.SystemColors.ControlDark
        Me.f.Location = New System.Drawing.Point(158, 103)
        Me.f.Name = "f"
        Me.f.Size = New System.Drawing.Size(75, 26)
        Me.f.TabIndex = 2
        '
        'd
        '
        Me.d.BackColor = System.Drawing.SystemColors.ControlDark
        Me.d.Location = New System.Drawing.Point(158, 61)
        Me.d.Name = "d"
        Me.d.Size = New System.Drawing.Size(75, 26)
        Me.d.TabIndex = 1
        '
        'g
        '
        Me.g.BackColor = System.Drawing.SystemColors.ControlDark
        Me.g.Location = New System.Drawing.Point(153, 19)
        Me.g.Name = "g"
        Me.g.Size = New System.Drawing.Size(80, 26)
        Me.g.TabIndex = 0
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripComboBox1, Me.ComboBox1})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(358, 25)
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripComboBox1
        '
        Me.ToolStripComboBox1.Name = "ToolStripComboBox1"
        Me.ToolStripComboBox1.Size = New System.Drawing.Size(52, 22)
        Me.ToolStripComboBox1.Text = "Account"
        '
        'ComboBox1
        '
        Me.ComboBox1.Items.AddRange(New Object() {"Tea", "Kbashiin", "Qaxwo", "bagees"})
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 25)
        Me.ComboBox1.Text = "Drink Type"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(358, 261)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents f As System.Windows.Forms.Label
    Friend WithEvents d As System.Windows.Forms.Label
    Friend WithEvents g As System.Windows.Forms.Label
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents txttotal As System.Windows.Forms.TextBox
    Friend WithEvents txttax As System.Windows.Forms.TextBox
    Friend WithEvents txtcost As System.Windows.Forms.TextBox
    Friend WithEvents ToolStripComboBox1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ComboBox1 As System.Windows.Forms.ToolStripComboBox
End Class
