﻿Public Class Form1

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txt1.TextChanged, txt2.TextChanged

    End Sub


    Private Sub ToolStripLabel1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles Panel1.Enter

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim user As String
        Dim pasword As Integer
        user = txt1.Text
        pasword = txt2.Text
        If user = "Anas" And pasword = 123 Then
            Me.Hide()
            Form2.Show()
        ElseIf user = "admin" And pasword <> 123 Then
            MsgBox("Pasword waa qalas")
        ElseIf user <> "admin" And pasword = 123 Then
            MsgBox("userka waa qalas")
        Else
            MsgBox("userka Ama Pasword waa qalas")

        End If
    End Sub
End Class
